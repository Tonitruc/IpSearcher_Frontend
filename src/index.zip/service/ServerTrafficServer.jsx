import axios from "axios";

const REST_API_BASE_URL = "http://localhost:8080/api/server_traffics/all"

export const serverTrafficsList = () =>  axios.get('http://localhost:8080/api/server_traffic/all');