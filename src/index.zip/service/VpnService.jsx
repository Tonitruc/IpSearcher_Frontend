import axios from "axios";
const apiUrl = 'http://localhost:8080/api';

export const listVpns = () =>  axios.get("http://localhost:8080/api/vpn/all");

export const getVpnById = (id) =>  axios.get('http://localhost:8080/api/vpn/get/' + id);

export const addVpn = (vpn) =>  axios.post('http://localhost:8080/api/vpn/' + "add_with_exist_ip", vpn);

export const updateVpn = (id, vpn) => axios.put('http://localhost:8080/api/vpn/' + "update?id=" + id, vpn);

export const deleteVpn = (id) => axios.delete('http://localhost:8080/api/vpn/' + "delete/" + id); 

export const removeIp = (id, ip) => axios.put(`http://localhost:8080/api/vpn/remove_ip/${id}?ip=${ip}`);

export const addIP = (id, ip) => axios.put(`localhost:8080/api/vpn/add_ip/${id}?ip=${ip}`);
