import React, { useState } from 'react';
import { addIP } from '../service/VpnService';
import './AddVpnIpStyle.css';

const ModalVpnIp = ({ vpnId, onClose }) => {
    const [trafficName, setTrafficName] = useState('');
    const [ip, setIp] = useState('');

    const handleSave = () => {
        addIP(vpnId, trafficName, ip)
            .then(() => {
                setTrafficName('');
                setIp('');
                onClose();
            })
            .catch(error => {
                console.error('Error adding IP:', error);
            });
    };

    return (
        <div className="ip-modal-wrapper">
            <div className="ip-modal" tabIndex="-1">
            <div className="modal-content">
                <h2>Add VPN IP</h2>
                <div>
                    <label htmlFor="trafficName">Enter traffic name:</label>
                    <input type="text" id="trafficName" value={trafficName} onChange={e => setTrafficName(e.target.value)} />
                </div>
                <div>
                    <label htmlFor="ip">Enter IP:</label>
                    <input type="text" id="ip" value={ip} onChange={e => setIp(e.target.value)} />
                </div>
                <button onClick={handleSave}>Save</button>
                <button onClick={onClose}>Cancel</button>
            </div>
        </div>
        </div>
    );
};

export default ModalVpnIp;
